using System;
using System.Collections.Generic;

namespace ScreenStocksLocalBridge.Models
{
    [Serializable]
    public class TickFrame
    {
        public long timestamp { get; set; }
        public long serverTick { get; set; }
        public bool marketReady { get; set; }
        public PlayerInfo player { get; set; }
        public Dictionary<string, StockTick> stocks { get; set; }
        public List<string> unlockedStocks { get; set; }

        public TickFrame()
        {
            stocks = new Dictionary<string, StockTick>();
            unlockedStocks = new List<string>();
        }
    }

    [Serializable]
    public class PlayerInfo
    {
        public string cash { get; set; }
        public double cashDouble { get; set; }
        public string netWorth { get; set; }
        public double netWorthDouble { get; set; }
        public int level { get; set; }
        public int ipoCount { get; set; }
        public int unlockedAchievementCount { get; set; }
        public float buyCooldownSeconds { get; set; }
        public float shortCooldownSeconds { get; set; }
        public double totalUnrealizedPnL { get; set; }
    }

    [Serializable]
    public class StockTick
    {
        public string ticker { get; set; }
        public string name { get; set; }
        public float price { get; set; }
        public float basePrice { get; set; }
        public float priceCap { get; set; }
        public float dividendRate { get; set; }
        public int maxVolume { get; set; }
        public int requiredAchievements { get; set; }
        public string availableShares { get; set; }
        public bool unlocked { get; set; }
        public PositionInfo holding { get; set; }
    }

    [Serializable]
    public class PositionInfo
    {
        public string ticker { get; set; }
        public string sharesOwned { get; set; }
        public double sharesOwnedDouble { get; set; }
        public float averageBuyPrice { get; set; }
        public string sharesShorted { get; set; }
        public double sharesShortedDouble { get; set; }
        public float averageShortPrice { get; set; }
        public double unrealizedPnL { get; set; }
    }

    [Serializable]
    public class TransactionRequest
    {
        public string id { get; set; }
        public string action { get; set; }
        public string ticker { get; set; }
        public string amount { get; set; }
        public int percent { get; set; }
        public bool isMax { get; set; }
    }

    [Serializable]
    public class TransactionResponse
    {
        public string id { get; set; }
        public bool success { get; set; }
        public string action { get; set; }
        public string ticker { get; set; }
        public string message { get; set; }
        public long timestampMs { get; set; }
        public string currentCash { get; set; }
        public PositionInfo updatedPosition { get; set; }
    }
}
