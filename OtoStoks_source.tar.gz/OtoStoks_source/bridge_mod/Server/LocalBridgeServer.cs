using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.WebSockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;
using ScreenStocksLocalBridge.Core;
using ScreenStocksLocalBridge.Models;

namespace ScreenStocksLocalBridge.Server
{
    public class LocalBridgeServer
    {
        private HttpListener _listener;
        private CancellationTokenSource _cts;
        private readonly int _port;
        private readonly List<WebSocket> _activeSockets = new List<WebSocket>();
        private readonly object _socketLock = new object();

        // Thread-safe transaction queue processed by Unity main thread in Update()
        public static readonly ConcurrentQueue<TransactionRequest> PendingTransactions = new ConcurrentQueue<TransactionRequest>();
        public static readonly ConcurrentDictionary<string, TaskCompletionSource<TransactionResponse>> PendingCallbacks = 
            new ConcurrentDictionary<string, TaskCompletionSource<TransactionResponse>>();

        public bool IsRunning
        {
            get { return _listener != null && _listener.IsListening; }
        }

        public LocalBridgeServer(int port)
        {
            _port = port;
        }

        public void Start()
        {
            if (IsRunning) return;

            _cts = new CancellationTokenSource();
            _listener = new HttpListener();
            // Strictly bind to local loopback (127.0.0.1)
            _listener.Prefixes.Add(string.Format("http://127.0.0.1:{0}/", _port));
            _listener.Start();

            Task.Run(new Func<Task>(() => AcceptConnectionsLoop(_cts.Token)));
            UnityEngine.Debug.Log(string.Format("[ScreenStocksLocalBridge] Server listening on http://127.0.0.1:{0}/ and ws://127.0.0.1:{0}/ws", _port));
        }

        public void Stop()
        {
            try
            {
                if (_cts != null) _cts.Cancel();

                lock (_socketLock)
                {
                    foreach (var ws in _activeSockets)
                    {
                        if (ws.State == WebSocketState.Open)
                        {
                            ws.CloseAsync(WebSocketCloseStatus.NormalClosure, "Server stopping", CancellationToken.None).Wait(1000);
                        }
                    }
                    _activeSockets.Clear();
                }

                if (_listener != null && _listener.IsListening)
                {
                    _listener.Stop();
                    _listener.Close();
                }
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError(string.Format("[ScreenStocksLocalBridge] Error stopping server: {0}", ex.Message));
            }
        }

        private async Task AcceptConnectionsLoop(CancellationToken ct)
        {
            while (!ct.IsCancellationRequested && _listener.IsListening)
            {
                try
                {
                    var context = await _listener.GetContextAsync();
                    if (context.Request.IsWebSocketRequest)
                    {
                        var t = ProcessWebSocketRequest(context, ct);
                    }
                    else
                    {
                        var t = ProcessHttpRequest(context);
                    }
                }
                catch (HttpListenerException)
                {
                    break;
                }
                catch (Exception ex)
                {
                    UnityEngine.Debug.LogWarning(string.Format("[ScreenStocksLocalBridge] Listener exception: {0}", ex.Message));
                }
            }
        }

        private async Task ProcessWebSocketRequest(HttpListenerContext context, CancellationToken ct)
        {
            HttpListenerWebSocketContext wsContext = null;
            try
            {
                wsContext = await context.AcceptWebSocketAsync(null);
            }
            catch (Exception ex)
            {
                context.Response.StatusCode = 500;
                context.Response.Close();
                UnityEngine.Debug.LogError(string.Format("[ScreenStocksLocalBridge] WebSocket accept failed: {0}", ex.Message));
                return;
            }

            WebSocket webSocket = wsContext.WebSocket;
            lock (_socketLock)
            {
                _activeSockets.Add(webSocket);
            }

            UnityEngine.Debug.Log("[ScreenStocksLocalBridge] Runner connected via WebSocket.");

            try
            {
                var initialFrame = TradingBridge.Instance.GetMultiStockSnapshot();
                string initialJson = JsonConvert.SerializeObject(initialFrame, Formatting.None);
                byte[] initBytes = Encoding.UTF8.GetBytes(initialJson);
                await webSocket.SendAsync(new ArraySegment<byte>(initBytes), WebSocketMessageType.Text, true, ct);
            }
            catch { }

            byte[] buffer = new byte[8192];
            var ms = new MemoryStream();

            try
            {
                while (webSocket.State == WebSocketState.Open && !ct.IsCancellationRequested)
                {
                    var result = await webSocket.ReceiveAsync(new ArraySegment<byte>(buffer), ct);
                    if (result.MessageType == WebSocketMessageType.Close)
                    {
                        await webSocket.CloseAsync(WebSocketCloseStatus.NormalClosure, "Closing", ct);
                        break;
                    }

                    ms.Write(buffer, 0, result.Count);
                    if (result.EndOfMessage)
                    {
                        string message = Encoding.UTF8.GetString(ms.ToArray());
                        ms.SetLength(0);
                        ProcessIncomingPayload(message, webSocket);
                    }
                }
            }
            catch (Exception) { }
            finally
            {
                lock (_socketLock)
                {
                    _activeSockets.Remove(webSocket);
                }
                try { webSocket.Dispose(); } catch { }
                UnityEngine.Debug.Log("[ScreenStocksLocalBridge] Runner WebSocket disconnected.");
            }
        }

        private void ProcessIncomingPayload(string json, WebSocket senderSocket)
        {
            if (string.IsNullOrEmpty(json) || string.IsNullOrEmpty(json.Trim())) return;

            try
            {
                var req = JsonConvert.DeserializeObject<TransactionRequest>(json);
                if (req == null) return;

                if (string.IsNullOrEmpty(req.id))
                {
                    req.id = Guid.NewGuid().ToString("N");
                }

                if (senderSocket != null && senderSocket.State == WebSocketState.Open)
                {
                    var tcs = new TaskCompletionSource<TransactionResponse>();
                    PendingCallbacks[req.id] = tcs;

                    tcs.Task.ContinueWith(t =>
                    {
                        if (t.IsCompleted && senderSocket.State == WebSocketState.Open)
                        {
                            try
                            {
                                string respJson = JsonConvert.SerializeObject(t.Result, Formatting.None);
                                byte[] respBytes = Encoding.UTF8.GetBytes(respJson);
                                senderSocket.SendAsync(new ArraySegment<byte>(respBytes), WebSocketMessageType.Text, true, CancellationToken.None);
                            }
                            catch { }
                        }
                    });
                }

                PendingTransactions.Enqueue(req);
            }
            catch (Exception ex)
            {
                UnityEngine.Debug.LogError(string.Format("[ScreenStocksLocalBridge] Failed to parse transaction payload: {0}", ex.Message));
            }
        }

        private async Task ProcessHttpRequest(HttpListenerContext context)
        {
            var req = context.Request;
            var res = context.Response;

            res.Headers.Add("Access-Control-Allow-Origin", "*");
            res.Headers.Add("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
            res.Headers.Add("Access-Control-Allow-Headers", "Content-Type");

            if (req.HttpMethod == "OPTIONS")
            {
                res.StatusCode = 200;
                res.Close();
                return;
            }

            string path = req.Url.AbsolutePath.ToLowerInvariant();
            try
            {
                if (req.HttpMethod == "GET")
                {
                    if (path == "/health")
                    {
                        SendJsonResponse(res, new { status = "ok", ready = TradingBridge.Instance.IsMarketReady });
                        return;
                    }
                    if (path == "/ticks" || path == "/snapshot")
                    {
                        var frame = TradingBridge.Instance.GetMultiStockSnapshot();
                        SendJsonResponse(res, frame);
                        return;
                    }
                    if (path == "/portfolio")
                    {
                        var frame = TradingBridge.Instance.GetMultiStockSnapshot();
                        SendJsonResponse(res, new { player = frame.player, stocks = frame.stocks });
                        return;
                    }
                }
                else if (req.HttpMethod == "POST" && path == "/trade")
                {
                    using (var reader = new StreamReader(req.InputStream, req.ContentEncoding))
                    {
                        string body = await reader.ReadToEndAsync();
                        var transReq = JsonConvert.DeserializeObject<TransactionRequest>(body);
                        if (transReq == null)
                        {
                            res.StatusCode = 400;
                            SendJsonResponse(res, new { error = "Invalid trade payload" });
                            return;
                        }

                        if (string.IsNullOrEmpty(transReq.id))
                        {
                            transReq.id = Guid.NewGuid().ToString("N");
                        }

                        var tcs = new TaskCompletionSource<TransactionResponse>();
                        PendingCallbacks[transReq.id] = tcs;
                        PendingTransactions.Enqueue(transReq);

                        var completedTask = await Task.WhenAny(tcs.Task, Task.Delay(2500));
                        if (completedTask == tcs.Task)
                        {
                            SendJsonResponse(res, tcs.Task.Result);
                        }
                        else
                        {
                            res.StatusCode = 202;
                            SendJsonResponse(res, new { id = transReq.id, status = "enqueued", message = "Order scheduled on Unity main thread" });
                        }
                        return;
                    }
                }

                res.StatusCode = 404;
                SendJsonResponse(res, new { error = "Endpoint not found" });
            }
            catch (Exception ex)
            {
                res.StatusCode = 500;
                SendJsonResponse(res, new { error = ex.Message });
            }
        }

        private void SendJsonResponse(HttpListenerResponse res, object data)
        {
            string json = JsonConvert.SerializeObject(data, Formatting.None);
            byte[] bytes = Encoding.UTF8.GetBytes(json);
            res.ContentType = "application/json; charset=utf-8";
            res.ContentLength64 = bytes.Length;
            res.OutputStream.Write(bytes, 0, bytes.Length);
            res.Close();
        }

        public void BroadcastTickFrame(TickFrame frame)
        {
            lock (_socketLock)
            {
                if (_activeSockets.Count == 0) return;

                string json = JsonConvert.SerializeObject(frame, Formatting.None);
                byte[] bytes = Encoding.UTF8.GetBytes(json);
                var segment = new ArraySegment<byte>(bytes);

                for (int i = _activeSockets.Count - 1; i >= 0; i--)
                {
                    var ws = _activeSockets[i];
                    if (ws.State == WebSocketState.Open)
                    {
                        try
                        {
                            ws.SendAsync(segment, WebSocketMessageType.Text, true, CancellationToken.None);
                        }
                        catch
                        {
                            _activeSockets.RemoveAt(i);
                        }
                    }
                    else
                    {
                        _activeSockets.RemoveAt(i);
                    }
                }
            }
        }
    }
}
