using System;
using System.Threading.Tasks;
using HarmonyLib;
using ScreenStocksLocalBridge.Core;
using UnityEngine;

namespace ScreenStocksLocalBridge.Patches
{
    /// <summary>
    /// Hooks into market tick updates across ALL tickers and captures real-time price movements.
    /// </summary>
    [HarmonyPatch(typeof(StockManager))]
    public static class MarketPatches
    {
        [HarmonyPatch("HandlePriceChanged")]
        [HarmonyPostfix]
        public static void Postfix_HandlePriceChanged(string stockId)
        {
            try
            {
                TradingBridge.Instance.NotifyTick();
            }
            catch (Exception ex)
            {
                Debug.LogWarning(string.Format("[ScreenStocksLocalBridge] Error in HandlePriceChanged hook: {0}", ex.Message));
            }
        }

        [HarmonyPatch("HandleRawPriceStep")]
        [HarmonyPostfix]
        public static void Postfix_HandleRawPriceStep()
        {
            try
            {
                TradingBridge.Instance.NotifyTick();
            }
            catch { }
        }

        [HarmonyPatch("ApplyBuyResult")]
        [HarmonyPostfix]
        public static void Postfix_ApplyBuyResult(string stockId)
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("ApplySellResult")]
        [HarmonyPostfix]
        public static void Postfix_ApplySellResult(string stockId)
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("ApplyShortResult")]
        [HarmonyPostfix]
        public static void Postfix_ApplyShortResult(string stockId)
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("ApplyCoverResult")]
        [HarmonyPostfix]
        public static void Postfix_ApplyCoverResult(string stockId)
        {
            TradingBridge.Instance.NotifyTick();
        }
    }

    /// <summary>
    /// Eliminates remote Steam networking, remote real-time WebSocket telemetry, and P2P calls.
    /// Ensures 100% offline local loopback execution.
    /// </summary>
    public static class RemoteNetworkingNeutralizer
    {
        public static void ApplyNeutralization(Harmony harmony)
        {
            try
            {
                var realtimeClientType = AccessTools.TypeByName("ScreenStocks.Net.ScreenStocksRealtimeClient");
                if (realtimeClientType != null)
                {
                    var connectMethod = AccessTools.Method(realtimeClientType, "ConnectAsync");
                    if (connectMethod != null)
                    {
                        var prefix = new HarmonyMethod(typeof(RemoteNetworkingNeutralizer), "BlockRealtimeConnect");
                        harmony.Patch(connectMethod, prefix: prefix);
                        Debug.Log("[ScreenStocksLocalBridge] Neutralized ScreenStocksRealtimeClient.ConnectAsync");
                    }
                }

                var ticketProviderType = AccessTools.TypeByName("ScreenStocks.Net.SteamSessionTicketProvider");
                if (ticketProviderType != null)
                {
                    var getTicketMethod = AccessTools.Method(ticketProviderType, "GetTicketAsync");
                    if (getTicketMethod != null)
                    {
                        var prefix = new HarmonyMethod(typeof(RemoteNetworkingNeutralizer), "BlockSteamTicketProvider");
                        harmony.Patch(getTicketMethod, prefix: prefix);
                        Debug.Log("[ScreenStocksLocalBridge] Neutralized SteamSessionTicketProvider.GetTicketAsync");
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.LogWarning(string.Format("[ScreenStocksLocalBridge] Network neutralization notice: {0}", ex.Message));
            }
        }

        public static bool BlockRealtimeConnect(ref Task __result)
        {
            __result = Task.CompletedTask;
            return false;
        }

        public static bool BlockSteamTicketProvider()
        {
            return false;
        }
    }
}
