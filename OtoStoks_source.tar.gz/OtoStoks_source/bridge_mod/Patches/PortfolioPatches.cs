using System;
using HarmonyLib;
using ScreenStocksLocalBridge.Core;
using UnityEngine;

namespace ScreenStocksLocalBridge.Patches
{
    /// <summary>
    /// Hooks into wallet cash mutations and portfolio transitions to trigger instantaneous local state updates.
    /// </summary>
    [HarmonyPatch(typeof(GameManager))]
    public static class PortfolioPatches
    {
        [HarmonyPatch("AddMoney")]
        [HarmonyPostfix]
        public static void Postfix_AddMoney()
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("SpendMoney")]
        [HarmonyPostfix]
        public static void Postfix_SpendMoney()
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("AdjustMoney")]
        [HarmonyPostfix]
        public static void Postfix_AdjustMoney()
        {
            TradingBridge.Instance.NotifyTick();
        }

        [HarmonyPatch("SetMoney")]
        [HarmonyPostfix]
        public static void Postfix_SetMoney()
        {
            TradingBridge.Instance.NotifyTick();
        }
    }
}
