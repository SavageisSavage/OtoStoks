using System;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using ScreenStocksLocalBridge.Core;
using ScreenStocksLocalBridge.Models;
using ScreenStocksLocalBridge.Patches;
using ScreenStocksLocalBridge.Server;
using UnityEngine;

namespace ScreenStocksLocalBridge
{
    [BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
    [BepInProcess("Screen Stocks.exe")]
    public class Plugin : BaseUnityPlugin
    {
        public static Plugin Instance { get; private set; }

        private Harmony _harmony;
        private LocalBridgeServer _server;

        private ConfigEntry<int> _serverPort;
        private ConfigEntry<int> _tickIntervalMs;
        private ConfigEntry<bool> _neutralizeRemoteTelemetry;

        private float _nextTickTime = 0f;
        private bool _isTickDirty = false;

        private void Awake()
        {
            Instance = this;

            // Bind plugin settings
            _serverPort = Config.Bind("Network", "ServerPort", 8765, "Local loopback port for WebSocket and HTTP API (127.0.0.1)");
            _tickIntervalMs = Config.Bind("Streaming", "TickIntervalMs", 50, "Interval in milliseconds between multi-stock tick frame broadcasts");
            _neutralizeRemoteTelemetry = Config.Bind("Safety", "NeutralizeRemoteTelemetry", true, "Eliminate Steam network and remote telemetry modules");

            Logger.LogInfo(string.Format("Initializing {0} v{1}...", PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION));

            // Apply Harmony patches
            try
            {
                _harmony = new Harmony(PluginInfo.PLUGIN_GUID);
                _harmony.PatchAll();

                if (_neutralizeRemoteTelemetry.Value)
                {
                    RemoteNetworkingNeutralizer.ApplyNeutralization(_harmony);
                }

                Logger.LogInfo("Harmony hooks registered successfully.");
            }
            catch (Exception ex)
            {
                Logger.LogError(string.Format("Failed to patch Harmony: {0}", ex));
            }

            // Hook tick update event
            TradingBridge.Instance.OnTickUpdated += HandleTickUpdated;

            // Start local loopback server
            try
            {
                _server = new LocalBridgeServer(_serverPort.Value);
                _server.Start();
                Logger.LogInfo(string.Format("Multi-Stock Local Bridge active at ws://127.0.0.1:{0}/ws", _serverPort.Value));
            }
            catch (Exception ex)
            {
                Logger.LogError(string.Format("Failed to start LocalBridgeServer: {0}", ex));
            }
        }

        private void HandleTickUpdated()
        {
            _isTickDirty = true;
        }

        private void Update()
        {
            // 1. Thread-safe transaction drain: Execute all runner payloads on the Unity main thread
            TransactionRequest req;
            while (LocalBridgeServer.PendingTransactions.TryDequeue(out req))
            {
                try
                {
                    TransactionResponse response = TradingBridge.Instance.ExecuteTransaction(req);

                    TaskCompletionSource<TransactionResponse> tcs;
                    if (!string.IsNullOrEmpty(req.id) && LocalBridgeServer.PendingCallbacks.TryRemove(req.id, out tcs))
                    {
                        tcs.TrySetResult(response);
                    }
                }
                catch (Exception ex)
                {
                    Logger.LogError(string.Format("Transaction execution error on main thread: {0}", ex.Message));
                    TaskCompletionSource<TransactionResponse> tcs;
                    if (!string.IsNullOrEmpty(req.id) && LocalBridgeServer.PendingCallbacks.TryRemove(req.id, out tcs))
                    {
                        var errResp = new TransactionResponse
                        {
                            id = req.id,
                            action = req.action,
                            ticker = req.ticker,
                            success = false,
                            message = string.Format("Engine error: {0}", ex.Message)
                        };
                        tcs.TrySetResult(errResp);
                    }
                }
            }

            // 2. Stream multi-stock tick frames to external runner
            if (_server != null && _server.IsRunning)
            {
                float now = Time.realtimeSinceStartup;
                float intervalSec = Mathf.Max(0.01f, _tickIntervalMs.Value / 1000f);

                if (_isTickDirty || now >= _nextTickTime)
                {
                    _isTickDirty = false;
                    _nextTickTime = now + intervalSec;

                    try
                    {
                        TickFrame frame = TradingBridge.Instance.GetMultiStockSnapshot();
                        _server.BroadcastTickFrame(frame);
                    }
                    catch (Exception ex)
                    {
                        Logger.LogWarning(string.Format("Tick broadcast warning: {0}\nStack: {1}", ex.Message, ex.StackTrace));
                    }
                }
            }
        }

        private void OnDestroy()
        {
            Logger.LogInfo("Shutting down ScreenStocks Local Bridge...");
            if (_server != null)
            {
                _server.Stop();
            }
            if (_harmony != null)
            {
                _harmony.UnpatchSelf();
            }
        }
    }

    public static class PluginInfo
    {
        public const string PLUGIN_GUID = "com.antigravity.screenstocks.localbridge";
        public const string PLUGIN_NAME = "ScreenStocks Multi-Stock Local Bridge";
        public const string PLUGIN_VERSION = "1.0.0";
    }
}
