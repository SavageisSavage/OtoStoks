using System;
using System.Collections.Generic;
using ScreenStocksLocalBridge.Models;
using UnityEngine;

namespace ScreenStocksLocalBridge.Core
{
    public class TradingBridge
    {
        private static TradingBridge _instance;
        public static TradingBridge Instance
        {
            get
            {
                if (_instance == null) _instance = new TradingBridge();
                return _instance;
            }
        }

        public bool IsMarketReady
        {
            get { return StockManager.I != null && GameManager.I != null; }
        }

        public event Action OnTickUpdated;

        public void NotifyTick()
        {
            if (OnTickUpdated != null)
            {
                OnTickUpdated();
            }
        }

        public static long GetCurrentUnixMs()
        {
            return (long)(DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc)).TotalMilliseconds;
        }

        public TickFrame GetMultiStockSnapshot()
        {
            var frame = new TickFrame
            {
                timestamp = GetCurrentUnixMs(),
                serverTick = StockManager.I != null ? StockManager.I.GetCurrentMarketTick() : 0L,
                marketReady = IsMarketReady
            };

            if (!IsMarketReady)
            {
                frame.player = new PlayerInfo
                {
                    cash = "0",
                    netWorth = "0",
                    level = 1,
                    ipoCount = 0
                };
                return frame;
            }

            double totalUnrealizedPnL = 0.0;
            string cashStr = "0";
            double cashDbl = 0.0;
            int playerLvl = 1;
            int effectiveIpo = 0;
            int achCount = 0;

            if (GameManager.I != null)
            {
                playerLvl = GameManager.I.PlayerLevel;
                effectiveIpo = GameManager.I.EffectiveIPOCount;
                try
                {
                    achCount = GameManager.I.UnlockedAchievementCount;
                }
                catch { }
                if (GameManager.I.Money != null)
                {
                    cashStr = GameManager.I.Money.ToString();
                    cashDbl = GameManager.I.Money.ToDouble();
                }
            }

            var playerInfo = new PlayerInfo
            {
                cash = cashStr,
                cashDouble = cashDbl,
                level = playerLvl,
                ipoCount = effectiveIpo,
                unlockedAchievementCount = achCount,
                buyCooldownSeconds = 0f,
                shortCooldownSeconds = 0f
            };

            IEnumerable<StockSO> stocksList = null;
            try
            {
                if (GameManager.I != null)
                {
                    stocksList = GameManager.I.GetAvailableStocks();
                }
            }
            catch { }

            if (stocksList == null)
            {
                try
                {
                    stocksList = Resources.FindObjectsOfTypeAll<StockSO>();
                }
                catch { }
            }

            if (stocksList != null && StockManager.I != null)
            {
                foreach (var stock in stocksList)
                {
                    if (stock == null || string.IsNullOrEmpty(stock.stockId))
                        continue;

                    string ticker = stock.stockId;
                    float currentPrice = 0f;
                    try
                    {
                        currentPrice = StockManager.I.GetCurrentPrice(ticker);
                    }
                    catch { }

                    StockPosition position = null;
                    try
                    {
                        position = StockManager.I.GetPosition(ticker);
                    }
                    catch { }

                    double sharesOwnedDouble = 0.0;
                    double sharesShortedDouble = 0.0;
                    string sharesOwnedStr = "0";
                    string sharesShortedStr = "0";
                    float avgBuyPrice = 0f;
                    float avgShortPrice = 0f;

                    if (position != null)
                    {
                        if (position.sharesOwned != null)
                        {
                            sharesOwnedDouble = position.sharesOwned.ToDouble();
                            sharesOwnedStr = position.sharesOwned.ToString();
                        }
                        if (position.sharesShorted != null)
                        {
                            sharesShortedDouble = position.sharesShorted.ToDouble();
                            sharesShortedStr = position.sharesShorted.ToString();
                        }
                        avgBuyPrice = position.averageBuyPrice;
                        avgShortPrice = position.averageShortPrice;
                    }

                    // Strict dynamic unlocked check for universal player support
                    bool isUnlocked = false;
                    try
                    {
                        if (GameManager.I != null)
                        {
                            isUnlocked = GameManager.I.IsStockUnlocked(ticker);
                        }
                    }
                    catch { }

                    // If user has an open position (shares owned or shorted), keep it active to allow closing/managing
                    if (!isUnlocked && (sharesOwnedDouble > 0 || sharesShortedDouble > 0))
                    {
                        isUnlocked = true;
                    }

                    // Only show & trade stocks that the current player has unlocked!
                    if (!isUnlocked)
                    {
                        continue;
                    }

                    frame.unlockedStocks.Add(ticker);

                    double unrealizedPnL = 0.0;
                    if (sharesOwnedDouble > 0)
                    {
                        unrealizedPnL += sharesOwnedDouble * (currentPrice - avgBuyPrice);
                    }
                    if (sharesShortedDouble > 0)
                    {
                        unrealizedPnL += sharesShortedDouble * (avgShortPrice - currentPrice);
                    }
                    totalUnrealizedPnL += unrealizedPnL;

                    var posInfo = new PositionInfo
                    {
                        ticker = ticker,
                        sharesOwned = sharesOwnedStr,
                        sharesOwnedDouble = sharesOwnedDouble,
                        averageBuyPrice = avgBuyPrice,
                        sharesShorted = sharesShortedStr,
                        sharesShortedDouble = sharesShortedDouble,
                        averageShortPrice = avgShortPrice,
                        unrealizedPnL = Math.Round(unrealizedPnL, 2)
                    };

                    string availShares = "0";
                    try
                    {
                        availShares = StockManager.I.GetAvailableShares(ticker).ToString();
                    }
                    catch { }

                    var stockTick = new StockTick
                    {
                        ticker = ticker,
                        name = stock.stockName != null ? stock.stockName : ticker,
                        price = currentPrice,
                        basePrice = stock.basePrice,
                        priceCap = stock.priceCap,
                        dividendRate = stock.dividendRate,
                        maxVolume = stock.maxVolume,
                        requiredAchievements = stock.requiredAchievements,
                        availableShares = availShares,
                        unlocked = true,
                        holding = posInfo
                    };

                    frame.stocks[ticker] = stockTick;
                }
            }

            playerInfo.totalUnrealizedPnL = Math.Round(totalUnrealizedPnL, 2);
            double netWorthVal = playerInfo.cashDouble + totalUnrealizedPnL;
            playerInfo.netWorth = netWorthVal.ToString("F2");
            playerInfo.netWorthDouble = netWorthVal;
            frame.player = playerInfo;

            return frame;
        }

        public TransactionResponse ExecuteTransaction(TransactionRequest req)
        {
            var res = new TransactionResponse
            {
                id = req.id,
                action = req.action,
                ticker = req.ticker,
                timestampMs = GetCurrentUnixMs(),
                success = false
            };

            if (!IsMarketReady)
            {
                res.message = "Market engine is not ready (StockManager or GameManager is null).";
                return res;
            }

            if (string.IsNullOrEmpty(req.ticker))
            {
                res.message = "Ticker symbol is required.";
                return res;
            }

            string ticker = req.ticker;
            string action = (req.action != null ? req.action : "").ToLowerInvariant().Trim();

            try
            {
                switch (action)
                {
                    case "buy":
                    case "buystock":
                        if (req.isMax || string.Equals(req.amount, "max", StringComparison.OrdinalIgnoreCase))
                        {
                            res.success = StockManager.I.BuyMax(ticker);
                            res.message = res.success ? string.Format("Executed BuyMax for {0}", ticker) : string.Format("Failed to BuyMax for {0}", ticker);
                        }
                        else if (req.percent > 0)
                        {
                            res.success = StockManager.I.BuyPercent(ticker, Mathf.Clamp(req.percent, 1, 100));
                            res.message = res.success ? string.Format("Executed BuyPercent {0}% for {1}", req.percent, ticker) : string.Format("Failed to BuyPercent for {0}", ticker);
                        }
                        else
                        {
                            BigNumber amount = ParseAmount(req.amount);
                            res.success = StockManager.I.BuyShares(ticker, amount, null);
                            res.message = res.success ? string.Format("Bought {0} shares of {1}", amount, ticker) : string.Format("Failed to buy {0} shares of {1}", amount, ticker);
                        }
                        break;

                    case "sell":
                    case "sellstock":
                        if (req.isMax || string.Equals(req.amount, "max", StringComparison.OrdinalIgnoreCase))
                        {
                            StockManager.I.SellMax(ticker);
                            res.success = true;
                            res.message = string.Format("Executed SellMax for {0}", ticker);
                        }
                        else
                        {
                            BigNumber amount = ParseAmount(req.amount);
                            res.success = StockManager.I.SellShares(ticker, amount, null);
                            res.message = res.success ? string.Format("Sold {0} shares of {1}", amount, ticker) : string.Format("Failed to sell {0} shares of {1}", amount, ticker);
                        }
                        break;

                    case "short":
                    case "shortstock":
                        if (req.isMax || string.Equals(req.amount, "max", StringComparison.OrdinalIgnoreCase))
                        {
                            res.success = StockManager.I.ShortMax(ticker);
                            res.message = res.success ? string.Format("Executed ShortMax for {0}", ticker) : string.Format("Failed to ShortMax for {0}", ticker);
                        }
                        else if (req.percent > 0)
                        {
                            res.success = StockManager.I.ShortPercent(ticker, Mathf.Clamp(req.percent, 1, 100));
                            res.message = res.success ? string.Format("Executed ShortPercent {0}% for {1}", req.percent, ticker) : string.Format("Failed to ShortPercent for {0}", ticker);
                        }
                        else
                        {
                            BigNumber amount = ParseAmount(req.amount);
                            res.success = StockManager.I.ShortShares(ticker, amount, null);
                            res.message = res.success ? string.Format("Shorted {0} shares of {1}", amount, ticker) : string.Format("Failed to short {0} shares of {1}", amount, ticker);
                        }
                        break;

                    case "cover":
                    case "coverstock":
                        if (req.isMax || string.Equals(req.amount, "max", StringComparison.OrdinalIgnoreCase))
                        {
                            StockManager.I.CoverMax(ticker);
                            res.success = true;
                            res.message = string.Format("Executed CoverMax for {0}", ticker);
                        }
                        else
                        {
                            BigNumber amount = ParseAmount(req.amount);
                            res.success = StockManager.I.CoverShares(ticker, amount, null);
                            res.message = res.success ? string.Format("Covered {0} shares of {1}", amount, ticker) : string.Format("Failed to cover {0} shares of {1}", amount, ticker);
                        }
                        break;

                    case "close":
                    case "closestock":
                    case "closeposition":
                        StockManager.I.ClosePosition(ticker);
                        res.success = true;
                        res.message = string.Format("Closed all positions for {0}", ticker);
                        break;

                    default:
                        res.message = string.Format("Unknown transaction action: '{0}'. Expected buy, sell, short, cover, or close.", action);
                        res.success = false;
                        return res;
                }

                res.currentCash = GameManager.I.Money.ToString();
                StockPosition pos = StockManager.I.GetPosition(ticker);
                float curPrice = StockManager.I.GetCurrentPrice(ticker);
                double pnl = 0.0;
                double ownedDbl = pos.sharesOwned.ToDouble();
                double shortDbl = pos.sharesShorted.ToDouble();
                if (ownedDbl > 0) pnl += ownedDbl * (curPrice - pos.averageBuyPrice);
                if (shortDbl > 0) pnl += shortDbl * (pos.averageShortPrice - curPrice);

                res.updatedPosition = new PositionInfo
                {
                    ticker = ticker,
                    sharesOwned = pos.sharesOwned.ToString(),
                    sharesOwnedDouble = ownedDbl,
                    averageBuyPrice = pos.averageBuyPrice,
                    sharesShorted = pos.sharesShorted.ToString(),
                    sharesShortedDouble = shortDbl,
                    averageShortPrice = pos.averageShortPrice,
                    unrealizedPnL = Math.Round(pnl, 2)
                };
            }
            catch (Exception ex)
            {
                res.success = false;
                res.message = string.Format("Engine transaction exception: {0}", ex.Message);
            }

            return res;
        }

        private BigNumber ParseAmount(string amountStr)
        {
            if (string.IsNullOrEmpty(amountStr))
                return new BigNumber(1L);

            try
            {
                return BigNumber.Parse(amountStr);
            }
            catch
            {
                double dVal;
                if (double.TryParse(amountStr, out dVal))
                {
                    return (BigNumber)dVal;
                }
                return new BigNumber(1L);
            }
        }
    }
}
