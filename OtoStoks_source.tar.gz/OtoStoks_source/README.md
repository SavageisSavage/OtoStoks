# OtoStoksBot Pro - Autonomous Algorithmic Trading Engine

OtoStoksBot is a high-frequency, high-expectancy autonomous algorithmic trading bot and live web dashboard built for the Steam game **Screen Stocks**.

## Key Architecture & Features

### 1. Pure Mathematical Algorithmic Engine (Zero Prepacked Database Bloat)
OtoStoksBot replaces bulky prepacked databases with pure, high-performance mathematical state machines:
- **$PUMP (Parabolic Trailing Peak & 100% Short Reversal)**: Dynamically scales trailing stops as prices reach vertical levels ($15 -> $25 -> $50 -> $100+), captures peak exhaustion, slams into a 100% MAX Short to the $7.00-$9.20 base, covers, and buys long.
- **$DUMP (Bottom-Floor Reversal)**: Rides short down to deep floor cratering ($2.50-$5.50), covers and buys 100% MAX Long on bounce, and rides recovery back to $9.80+.
- **$TECH (Target X Dip-Buy & Crest-Short Loop)**: Accumulates dips at $8-$12, sells all long and opens 100% MAX Short at Target X ($16 default or $20/$25 presets), covers at dip bottom, and repeats.
- **$BASE (12:30 AM IST Crash Synchronization)**: Live countdown to daily 00:30 IST / 19:00 UTC crash, pre-crash liquidation, plunge short from $400-$900 to $1-$25, and bottom accumulation for 30x-50x player-market rebound.
- **$BANK (Deterministic Blacklist)**: Permanently ignored and filtered out across all systems.
- **Billionaire Dividend Vault (> $1B)**: 100% locked into top dividend yields ($STEP 2%, $STEAM 1.3%, $WAVE 1%), zero shorting, zero selling, permanent compound interest via automated DRIP.
- **Early Compounding Sizer**: Allocates 85% of capital for net worth < $50k to rapidly escape the early game.
- **Auto-Stop Full Liquidation**: Instantly liquidates all open positions to 100% cash when Auto Mode is stopped.

### 2. High-Speed Protocol Buffer Data Collection & Online Retraining
- Replaces slow, heavy JSON and SQLite queries with Google Protocol Buffers (`.pb`).
- Captures live game ticks at microsecond serialization speeds.
- Writes length-prefixed streaming batches into `data/otostoks_ticks.pb`.
- Background worker continuously retrains on newly collected live ticks with zero game lag.

### 3. Human-Crafted Financial Terminal UI
- **Live SVG Sparklines**: 20-tick vector trend lines embedded in every stock row with glowing apex dots.
- **Real-Time Price Flash Pulses**: Emerald/rose glow on every live tick.
- **Session Realized Alpha Ledger**: Live tracking of completed trades, realized P&L, win rate %, and profit factor.
- **One-Click Strategy Presets**: `⚡ Turbo Snowball`, `📈 Growth Core`, `🛡️ Capital Shield`, and `👑 Billionaire Vault`.
- **Built-in Web Audio Synthesizer**: Subtle chimes for BUY, SHORT, and CLOSE with quick mute/unmute toggle.
- **1-Click CSV Trade Export**: Download full execution audit logs directly from the browser.

## Quick Start
1. Double-click `START_OTOSTOKSBOT.bat` (or run `OtoStoksBot.exe`).
2. The dashboard will automatically launch at `http://127.0.0.1:8080`.
3. Open **Screen Stocks** on Steam (the bot will auto-detect and connect).
4. Click **Switch to AUTO MODE** to start trading.
